import React from 'react'

export const Description = ({ des }) => {
  return (
    <div className=' font-inter font-medium text-lg leading-7'>
      {des}
    </div>
  )
}
